1：启动应用
sh run.sh start prod|test  # prod|test 不写，则是研发环境

2：停止应用
sh run.sh stop

3：重启应用
sh run.sh restart prod|test # prod|test 不写，则是研发环境